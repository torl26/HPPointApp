"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HP_ERR_VALIDATE_ARGUMENT = exports.HP_ERR_VALIDATE_INPUT = exports.HP_ERR_VALIDATE_RULE = exports.HP_OK = void 0;
exports.HP_OK = 0;
exports.HP_ERR_VALIDATE_RULE = 3225616385;
exports.HP_ERR_VALIDATE_INPUT = 3225616386;
exports.HP_ERR_VALIDATE_ARGUMENT = 3225616387;
