"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_child_process_1 = require("node:child_process");
const node_test_1 = require("node:test");
const src_1 = require("../src");
function validateValue(value, rules) {
    const result = { errors: [] };
    const code = (0, src_1.hpValidate)({ value }, { value: rules }, result);
    return { code, result };
}
(0, node_test_1.test)("全10種類のルールを公開窓口から利用できる", () => {
    const result = { errors: [] };
    const code = (0, src_1.hpValidate)({
        name: "😀あ",
        email: "member@example.jp",
        birthDate: "2024-02-29",
        age: 20,
        accountType: "citizen",
        totpCode: "012345",
        month: "2026-11",
        notifyEnabled: false,
    }, {
        name: [{ kind: "required" }, { kind: "minLength", min: 2 }, { kind: "maxLength", max: 2 }],
        email: [{ kind: "email" }],
        birthDate: [{ kind: "date" }],
        age: [{ kind: "intRange", min: 0, max: 120 }],
        accountType: [{ kind: "oneOf", values: ["citizen", "staff"] }],
        totpCode: [{ kind: "pattern", pattern: "totp" }],
        month: [{ kind: "month" }],
        notifyEnabled: [{ kind: "boolean" }],
    }, result);
    strict_1.default.equal(code, src_1.HP_OK);
    strict_1.default.deepEqual(result.errors, []);
});
(0, node_test_1.test)("必須項目ではundefined・null・空文字をエラーにする", () => {
    for (const value of [undefined, null, ""]) {
        const { code, result } = validateValue(value, [{ kind: "required" }]);
        strict_1.default.equal(code, src_1.HP_ERR_VALIDATE_INPUT);
        strict_1.default.deepEqual(result.errors, [{ field: "value", rule: "required" }]);
    }
});
(0, node_test_1.test)("任意項目の空値はすべての入力検査を省略する", () => {
    const rules = [
        { kind: "minLength", min: 1 },
        { kind: "maxLength", max: 2 },
        { kind: "email" },
        { kind: "date" },
        { kind: "intRange", min: 1, max: 2 },
        { kind: "oneOf", values: ["citizen"] },
        { kind: "pattern", pattern: "totp" },
        { kind: "month" },
        { kind: "boolean" },
    ];
    for (const value of [undefined, null, ""]) {
        const { code, result } = validateValue(value, rules);
        strict_1.default.equal(code, src_1.HP_OK);
        strict_1.default.deepEqual(result.errors, []);
    }
});
(0, node_test_1.test)("0・false・空白だけの文字列を空値と扱わない", () => {
    for (const value of [0, false, "  "]) {
        strict_1.default.equal(validateValue(value, [{ kind: "required" }]).code, src_1.HP_OK);
    }
    strict_1.default.equal(validateValue(0, [{ kind: "intRange", min: 1, max: 2 }]).code, src_1.HP_ERR_VALIDATE_INPUT);
    strict_1.default.equal(validateValue(false, [{ kind: "oneOf", values: ["false"] }]).code, src_1.HP_ERR_VALIDATE_INPUT);
    strict_1.default.equal(validateValue("  ", [{ kind: "maxLength", max: 1 }]).code, src_1.HP_ERR_VALIDATE_INPUT);
});
(0, node_test_1.test)("文字数はコードポイント単位で数え、境界値を含む", () => {
    for (const value of ["a", "あ", "😀"]) {
        strict_1.default.equal(validateValue(value, [
            { kind: "minLength", min: 1 }, { kind: "maxLength", max: 1 },
        ]).code, src_1.HP_OK);
    }
    strict_1.default.equal(validateValue("😀a", [{ kind: "maxLength", max: 1 }]).code, src_1.HP_ERR_VALIDATE_INPUT);
    strict_1.default.equal(validateValue("a", [{ kind: "minLength", min: 2 }]).code, src_1.HP_ERR_VALIDATE_INPUT);
});
(0, node_test_1.test)("メールは基本形式を検査し、前後の空白を削除しない", () => {
    for (const value of ["member@example.jp", "member+tag@example.co.jp"]) {
        strict_1.default.equal(validateValue(value, [{ kind: "email" }]).code, src_1.HP_OK, value);
    }
    for (const value of ["member", "member@localhost", "@example.jp", "member@@example.jp", " member@example.jp", "member@example.jp\n"]) {
        strict_1.default.equal(validateValue(value, [{ kind: "email" }]).code, src_1.HP_ERR_VALIDATE_INPUT, value);
    }
});
(0, node_test_1.test)("日付は実在日とうるう年を検査する", () => {
    for (const value of ["0001-01-01", "0099-12-31", "2000-02-29", "2024-02-29", "2026-11-15", "9999-12-31"]) {
        strict_1.default.equal(validateValue(value, [{ kind: "date" }]).code, src_1.HP_OK, value);
    }
    for (const value of ["0000-01-01", "1900-02-29", "2026-02-29", "2026-04-31", "2026-00-01", "2026-13-01", "2026-01-00", "2026-01-32", "2026-1-01", "2026-11-15T00:00:00Z", "2026-11-15\n"]) {
        strict_1.default.equal(validateValue(value, [{ kind: "date" }]).code, src_1.HP_ERR_VALIDATE_INPUT, value);
    }
});
(0, node_test_1.test)("年月はYYYY-MM形式と月の範囲を検査する", () => {
    for (const value of ["0001-01", "2026-11", "9999-12"]) {
        strict_1.default.equal(validateValue(value, [{ kind: "month" }]).code, src_1.HP_OK, value);
    }
    for (const value of ["0000-01", "2026-00", "2026-13", "2026-1", "2026-11-15", "2026-11\n"]) {
        strict_1.default.equal(validateValue(value, [{ kind: "month" }]).code, src_1.HP_ERR_VALIDATE_INPUT, value);
    }
});
(0, node_test_1.test)("整数範囲は両端を含み、文字列・小数・NaN・無限大を拒否する", () => {
    const rules = [{ kind: "intRange", min: -1, max: 1 }];
    for (const value of [-1, 0, 1]) {
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_OK);
    }
    for (const value of [-2, 2, 0.5, "1", true, NaN, Infinity, -Infinity]) {
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_ERR_VALIDATE_INPUT, String(value));
    }
});
(0, node_test_1.test)("整数値とルールの上下限を安全な整数に制限する", () => {
    const rules = [{
            kind: "intRange", min: Number.MIN_SAFE_INTEGER, max: Number.MAX_SAFE_INTEGER,
        }];
    for (const value of [Number.MIN_SAFE_INTEGER, 0, Number.MAX_SAFE_INTEGER]) {
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_OK);
    }
    const rounded = JSON.parse('{"value":9007199254740993}').value;
    for (const value of [rounded, Number.MIN_SAFE_INTEGER - 1, 1e100]) {
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_ERR_VALIDATE_INPUT);
    }
    for (const rule of [
        { kind: "intRange", min: 0, max: 1e100 },
        { kind: "intRange", min: Number.MIN_SAFE_INTEGER - 1, max: 0 },
        { kind: "minLength", min: Number.MAX_SAFE_INTEGER + 1 },
        { kind: "maxLength", max: Number.MAX_SAFE_INTEGER + 1 },
    ]) {
        strict_1.default.equal(validateValue(1, [rule]).code, src_1.HP_ERR_VALIDATE_RULE);
    }
});
(0, node_test_1.test)("長さ違反後の長いメール検査でも処理が停止しない", () => {
    var _a;
    // 回帰で同期処理が止まっても、テスト全体を巻き込まないよう別プロセスで実行する。
    const script = `
    const assert = require('node:assert/strict');
    const { hpValidate, HP_ERR_VALIDATE_INPUT } = require(process.argv[1]);
    const result = { errors: [] };
    const code = hpValidate(
      { value: 'a@' + 'a.'.repeat(50000) + '\\n' },
      { value: [{ kind: 'maxLength', max: 255 }, { kind: 'email' }] },
      result,
    );
    assert.equal(code, HP_ERR_VALIDATE_INPUT);
    assert.deepEqual(result.errors.map(error => error.rule), ['maxLength', 'email']);
  `;
    const child = (0, node_child_process_1.spawnSync)(process.execPath, ["-e", script, require.resolve("../src")], {
        encoding: "utf8", timeout: 5000, windowsHide: true,
    });
    strict_1.default.equal(child.error, undefined, (_a = child.error) === null || _a === void 0 ? void 0 : _a.message);
    strict_1.default.equal(child.status, 0, child.stderr);
});
(0, node_test_1.test)("結合文字・複合絵文字はコードポイント単位で検査する", () => {
    strict_1.default.equal(validateValue("e\u0301", [{ kind: "maxLength", max: 1 }]).code, src_1.HP_ERR_VALIDATE_INPUT);
    strict_1.default.equal(validateValue("👨‍👩‍👧‍👦", [
        { kind: "minLength", min: 7 }, { kind: "maxLength", max: 7 },
    ]).code, src_1.HP_OK);
    for (const value of ["\n", "\t", "\u3000"]) {
        strict_1.default.equal(validateValue(value, [{ kind: "required" }, { kind: "minLength", min: 1 }]).code, src_1.HP_OK);
    }
});
(0, node_test_1.test)("oneOfは文字列を完全一致で比較する", () => {
    const rules = [{ kind: "oneOf", values: ["citizen", "staff"] }];
    strict_1.default.equal(validateValue("citizen", rules).code, src_1.HP_OK);
    for (const value of ["Citizen", " citizen", "shop", 1, false]) {
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_ERR_VALIDATE_INPUT);
    }
});
(0, node_test_1.test)("booleanはtrueとfalseを受け付け、変換しない", () => {
    const rules = [{ kind: "required" }, { kind: "boolean" }];
    for (const value of [true, false]) {
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_OK);
    }
    for (const value of ["true", "false", 0, 1, null, undefined, ""]) {
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_ERR_VALIDATE_INPUT);
    }
});
(0, node_test_1.test)("文字列用ルールは数値やオブジェクトを文字列へ変換しない", () => {
    const rules = [
        { kind: "minLength", min: 0 }, { kind: "maxLength", max: 100 },
        { kind: "email" }, { kind: "date" }, { kind: "month" },
        { kind: "pattern", pattern: "totp" },
    ];
    for (const value of [123, true, [], {}]) {
        const { code, result } = validateValue(value, rules);
        strict_1.default.equal(code, src_1.HP_ERR_VALIDATE_INPUT);
        strict_1.default.equal(result.errors.length, rules.length);
    }
});
(0, node_test_1.test)("TOTPの先頭のゼロを保持し、数字以外や余分な文字を拒否する", () => {
    const rules = [
        { kind: "required" },
        { kind: "minLength", min: 6 },
        { kind: "maxLength", max: 6 },
        { kind: "pattern", pattern: "totp" },
    ];
    strict_1.default.equal(validateValue("012345", rules).code, src_1.HP_OK);
    for (const value of ["12345", "1234567", "abcdef", "１２３４５６", "012345\n", "012345 ", 123456]) {
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_ERR_VALIDATE_INPUT, String(value));
    }
});
(0, node_test_1.test)("patternでUUID・16進数・接頭辞を検査できる", () => {
    const uuid = [
        { kind: "minLength", min: 36 }, { kind: "maxLength", max: 36 },
        { kind: "pattern", pattern: "uuid" },
    ];
    strict_1.default.equal(validateValue("550e8400-e29b-41d4-a716-446655440000", uuid).code, src_1.HP_OK);
    strict_1.default.equal(validateValue("z50e8400-e29b-41d4-a716-446655440000", uuid).code, src_1.HP_ERR_VALIDATE_INPUT);
    const hex = [
        { kind: "minLength", min: 64 }, { kind: "maxLength", max: 64 },
        { kind: "pattern", pattern: "hex64" },
    ];
    strict_1.default.equal(validateValue("a".repeat(64), hex).code, src_1.HP_OK);
    strict_1.default.equal(validateValue("z".repeat(64), hex).code, src_1.HP_ERR_VALIDATE_INPUT);
    const prefix = [{ kind: "pattern", pattern: "imageKey" }];
    strict_1.default.equal(validateValue("incoming/photo.jpg", prefix).code, src_1.HP_OK);
    strict_1.default.equal(validateValue("other/photo.jpg", prefix).code, src_1.HP_ERR_VALIDATE_INPUT);
});
(0, node_test_1.test)("名前指定のパターンは繰り返し実行しても結果が変わらない", () => {
    const rule = { kind: "pattern", pattern: "totp" };
    for (let attempt = 0; attempt < 3; attempt++) {
        strict_1.default.equal(validateValue("012345", [rule]).code, src_1.HP_OK);
        strict_1.default.equal(validateValue("abcdef", [rule]).code, src_1.HP_ERR_VALIDATE_INPUT);
    }
});
(0, node_test_1.test)("同一項目の複数エラーも、別項目のエラーも順に収集する", () => {
    const result = { errors: [] };
    strict_1.default.equal((0, src_1.hpValidate)({ name: "ab", email: "invalid", birthDate: "2026-02-29" }, {
        name: [{ kind: "minLength", min: 3 }, { kind: "maxLength", max: 1 }],
        email: [{ kind: "email" }],
        birthDate: [{ kind: "date" }],
    }, result), src_1.HP_ERR_VALIDATE_INPUT);
    strict_1.default.deepEqual(result.errors, [
        { field: "name", rule: "minLength" },
        { field: "name", rule: "maxLength" },
        { field: "email", rule: "email" },
        { field: "birthDate", rule: "date" },
    ]);
});
(0, node_test_1.test)("空の必須項目でも、満たさないルールをすべて収集する", () => {
    const { result } = validateValue("", [
        { kind: "required" }, { kind: "minLength", min: 8 }, { kind: "email" },
    ]);
    strict_1.default.deepEqual(result.errors.map((error) => error.rule), ["required", "minLength", "email"]);
});
(0, node_test_1.test)("結果を再利用しても前回のエラーを残さない", () => {
    const result = { errors: [] };
    const rules = { value: [{ kind: "required" }] };
    strict_1.default.equal((0, src_1.hpValidate)({}, rules, result), src_1.HP_ERR_VALIDATE_INPUT);
    strict_1.default.equal((0, src_1.hpValidate)({ value: "ok" }, rules, result), src_1.HP_OK);
    strict_1.default.deepEqual(result.errors, []);
});
(0, node_test_1.test)("入力とルールを変更せず、未定義の項目は検査しない", () => {
    const input = Object.freeze({ value: "  ok  ", extra: 123 });
    const rules = { value: [{ kind: "minLength", min: 6 }] };
    Object.freeze(rules.value[0]);
    Object.freeze(rules.value);
    Object.freeze(rules);
    const result = { errors: [] };
    strict_1.default.equal((0, src_1.hpValidate)(input, rules, result), src_1.HP_OK);
    strict_1.default.deepEqual(input, { value: "  ok  ", extra: 123 });
});
(0, node_test_1.test)("空のルールは成功し、継承された入力項目を必須値とみなさない", () => {
    const result = { errors: [] };
    const requiredRule = { kind: "required" };
    strict_1.default.equal((0, src_1.hpValidate)({}, {}, result), src_1.HP_OK);
    strict_1.default.equal((0, src_1.hpValidate)({}, { toString: [requiredRule] }, result), src_1.HP_ERR_VALIDATE_INPUT);
    strict_1.default.deepEqual(result.errors, [{ field: "toString", rule: "required" }]);
});
(0, node_test_1.test)("不正なルールは入力検査より先に検出し、結果を初期化する", () => {
    const invalidRules = [
        null, [], 1, new Date(), new Map(),
        { value: null }, { value: {} }, { value: [null] }, { value: [{}] },
        { value: [{ kind: "unknown" }] },
        { value: [{ kind: "minLength" }] },
        { value: [{ kind: "minLength", min: -1 }] },
        { value: [{ kind: "minLength", min: 1.5 }] },
        { value: [{ kind: "maxLength", max: "10" }] },
        { value: [{ kind: "maxLength", max: NaN }] },
        { value: [{ kind: "intRange", min: 10, max: 1 }] },
        { value: [{ kind: "intRange", min: 0, max: Infinity }] },
        { value: [{ kind: "intRange", min: 0.5, max: 1 }] },
        { value: [{ kind: "oneOf", values: [] }] },
        { value: [{ kind: "oneOf", values: [1] }] },
        { value: [{ kind: "oneOf", values: Array(1) }] },
        { value: [{ kind: "pattern", pattern: "[0-9]" }] },
        { value: [{ kind: "pattern", pattern: /^[0-9]{6}$/ }] },
        { value: [{ kind: "pattern", pattern: /^(a+)+$/ }] },
        { value: Array(1) },
        { first: [{ kind: "required" }], value: [{ kind: "unknown" }] },
    ];
    for (const rules of invalidRules) {
        const result = { errors: [{ field: "old", rule: "required" }] };
        // 実行時に不正なルールが渡された場合を意図的に再現する。
        strict_1.default.equal((0, src_1.hpValidate)({}, rules, result), src_1.HP_ERR_VALIDATE_RULE);
        strict_1.default.deepEqual(result.errors, []);
    }
});
(0, node_test_1.test)("interfaceで定義した入力をそのまま渡せる", () => {
    const input = { name: "市民", email: "member@example.jp" };
    const result = { errors: [] };
    strict_1.default.equal((0, src_1.hpValidate)(input, {
        name: [{ kind: "required" }], email: [{ kind: "email" }],
    }, result), src_1.HP_OK);
});
(0, node_test_1.test)("入力全体のnull・配列・クラスなどを引数エラーにする", () => {
    const inputs = [
        undefined, null, "value", 123, true, [], new Date(), new Map(),
        Object.create({ value: "inherited" }),
    ];
    const ruleSets = [{}, { value: [{ kind: "required" }] }];
    for (const input of inputs) {
        for (const rules of ruleSets) {
            const result = { errors: [{ field: "old", rule: "required" }] };
            strict_1.default.equal((0, src_1.hpValidate)(input, rules, result), src_1.HP_ERR_VALIDATE_ARGUMENT);
            strict_1.default.deepEqual(result.errors, []);
        }
    }
});
(0, node_test_1.test)("不正な出力先を例外にせず、引数エラーにする", () => {
    const results = [
        undefined, null, [], new Date(), {},
        Object.freeze({ errors: [] }), Object.preventExtensions({}),
    ];
    for (const result of results) {
        strict_1.default.equal((0, src_1.hpValidate)({}, {}, result), src_1.HP_ERR_VALIDATE_ARGUMENT);
    }
    const sealed = Object.seal({ errors: [] });
    strict_1.default.equal((0, src_1.hpValidate)({}, {}, sealed), src_1.HP_OK);
});
(0, node_test_1.test)("getterを呼び出さずに入力・ルール・出力の不正を検出する", () => {
    let getterCalls = 0;
    const accessor = {
        enumerable: true,
        get() { getterCalls++; throw new Error("getter must not run"); },
    };
    const input = Object.defineProperty({}, "value", accessor);
    const rules = Object.defineProperty({}, "value", accessor);
    const rule = Object.defineProperty({}, "kind", accessor);
    const result = { errors: [] };
    strict_1.default.equal((0, src_1.hpValidate)(input, {}, result), src_1.HP_ERR_VALIDATE_ARGUMENT);
    strict_1.default.equal((0, src_1.hpValidate)({}, rules, result), src_1.HP_ERR_VALIDATE_RULE);
    strict_1.default.equal((0, src_1.hpValidate)({}, { value: [rule] }, result), src_1.HP_ERR_VALIDATE_RULE);
    const output = Object.defineProperty({}, "errors", accessor);
    strict_1.default.equal((0, src_1.hpValidate)({}, {}, output), src_1.HP_ERR_VALIDATE_ARGUMENT);
    strict_1.default.equal(getterCalls, 0);
});
(0, node_test_1.test)("失効したProxyのメタデータ検査も例外を外へ出さない", () => {
    const { proxy, revoke } = Proxy.revocable({}, {});
    revoke();
    const result = { errors: [] };
    strict_1.default.equal((0, src_1.hpValidate)(proxy, {}, result), src_1.HP_ERR_VALIDATE_ARGUMENT);
    strict_1.default.equal((0, src_1.hpValidate)({}, proxy, result), src_1.HP_ERR_VALIDATE_RULE);
    strict_1.default.equal((0, src_1.hpValidate)({}, {}, proxy), src_1.HP_ERR_VALIDATE_ARGUMENT);
});
(0, node_test_1.test)("プロトタイプのないデータオブジェクトも利用できる", () => {
    const input = Object.assign(Object.create(null), { value: "012345" });
    const rules = Object.assign(Object.create(null), {
        value: [{ kind: "required" }, { kind: "pattern", pattern: "totp" }],
    });
    const result = Object.assign(Object.create(null), { errors: [] });
    strict_1.default.equal((0, src_1.hpValidate)(input, rules, result), src_1.HP_OK);
});
(0, node_test_1.test)("危険な正規表現は長さ制限にかかわらず実行せず拒否する", () => {
    var _a;
    const script = `
    const assert = require('node:assert/strict');
    const { hpValidate, HP_ERR_VALIDATE_RULE } = require(process.argv[1]);
    const result = { errors: [] };
    assert.equal(hpValidate(
      { value: 'a'.repeat(30) + '!' },
      { value: [{ kind: 'maxLength', max: 6 }, { kind: 'pattern', pattern: /^(a+)+$/ }] },
      result,
    ), HP_ERR_VALIDATE_RULE);
    assert.deepEqual(result.errors, []);
  `;
    const child = (0, node_child_process_1.spawnSync)(process.execPath, ["-e", script, require.resolve("../src")], {
        encoding: "utf8", timeout: 5000, windowsHide: true,
    });
    strict_1.default.equal(child.error, undefined, (_a = child.error) === null || _a === void 0 ? void 0 : _a.message);
    strict_1.default.equal(child.status, 0, child.stderr);
});
(0, node_test_1.test)("名前指定だけで各形式の余分な文字や改行を拒否する", () => {
    const cases = [
        { pattern: "totp", value: "012345" },
        { pattern: "uuid", value: "550E8400-E29B-41D4-A716-446655440000" },
        { pattern: "hex64", value: "A".repeat(64) },
    ];
    for (const { pattern, value } of cases) {
        const rules = [{ kind: "pattern", pattern }];
        strict_1.default.equal(validateValue(value, rules).code, src_1.HP_OK);
        for (const invalid of [value + "\n", " " + value, value.slice(1), "x".repeat(100000)]) {
            strict_1.default.equal(validateValue(invalid, rules).code, src_1.HP_ERR_VALIDATE_INPUT);
        }
    }
});
(0, node_test_1.test)("エラーコードは公開定数として一意に定義されている", () => {
    strict_1.default.deepEqual([src_1.HP_OK, src_1.HP_ERR_VALIDATE_RULE, src_1.HP_ERR_VALIDATE_INPUT, src_1.HP_ERR_VALIDATE_ARGUMENT], [
        0, 3225616385, 3225616386, 3225616387,
    ]);
});
